
package Crypt::ircDH1080;

use 5.010000;
use strict;
use warnings;

use Crypt::Random qw(makerandom);
use Math::BigInt try => 'GMP';
use Digest::SHA;

require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration       use Crypt::ircDH1080 ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = ( 'all' => [ qw(
) ] );

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
);

our $VERSION = '0.01';

my $B64_DH1080 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

my $P = Math::BigInt->from_hex('0x' . 
							   'FBE1022E23D213E8ACFA9AE8B9DFAD' .
							   'A3EA6B7AC7A7B7E95AB5EB2DF85892' .
							   '1FEADE95E6AC7BE7DE6ADBAB8A783E' .
							   '7AF7A7FA6A2B7BEB1E72EAE2B72F9F' .
							   'A2BFB2A2EFBEFAC868BADB3E828FA8' .
							   'BADFADA3E4CC1BE7E8AFE85E9698A7' .
							   '83EB68FA07A77AB6AD7BEB618ACF9C' .
							   'A2897EB28A6189EFA07AB99A8A7FA9' .
							   'AE299EFA7BA66DEAFEFBEFBF0B7D8B');

sub new {
	my ($class) = @_;

	my $g = Math::BigInt->new(2);
	my $p = $P;
	my $q = $p->copy()->bsub(1)->bdiv(2);

	my $private = Math::BigInt->new(makerandom(Size => 1080));
	my $public = $g->copy()->bmodpow($private, $p);

	my $self = {
		_private_key => $private,
		_public_key => $public,
		_q => $q,
		_p => $p,
		_g => $g
	};

	return bless $self, $class;
}

sub as_string {
	my ($self) = @_;

	return sprintf("Crypt::ircDH1080 public_key=%s, private_key=%s", $self->{_public_key}->bstr(),$self->{_private_key}->bstr());
}

sub public_key {
	my ($self) = @_;
	return Crypt::ircDH1080->encodeB64(Crypt::ircDH1080->int2bytes($self->{_public_key}));
}

sub get_shared_secret {
	my ($self, $peer_pub_key) = @_;

	my $public = Crypt::ircDH1080->bytes2int(Crypt::ircDH1080->decodeB64($peer_pub_key));
	if ($public->bcmp(1) <= 0 || $public->bcmp($self->{_p}) >= 0) {
		warn sprintf("Public key outside range: %s", $public->bstr());
		return undef;
	}

	#
	#if (!Crypt::ircDH1080->validate_public($public, $self->{_q}, $self->{_p})) {
	#warn "Invalid public key\n";
	#return undef;
	#}

	my $secret = $public->bmodpow($self->{_private_key}, $self->{_p});
	
	my $digest = Digest::SHA->new(256);
	$digest->add(Crypt::ircDH1080->int2bytes($secret));
	return Crypt::ircDH1080->encodeB64($digest->digest);
}

#sub validate_public {
#	my ($class, $public, $q, $p) = @_;
#
#	return 1 == $public->bmodpow($q, $p);
#}

sub bytes2int {
	my ($class, $a) = @_;

	my @b = split //, $a;
	my $n = Math::BigInt->new(0);

	foreach my $p (@b) {
		$n->bmul(256);
		$n->badd(ord($p));
	}
	return $n;
}

sub int2bytes {
	my ($class, $n) = @_;

	my $t = $n->copy();

	if ($t->is_zero()) {
		return "";
	}

	my $b = '';
	while ($t->bcmp(0) > 0) {
		$b = chr($t->copy()->bmod(256)->as_int()) . $b;
		$t->bdiv(256);
	}
	return $b;
}

sub encodeB64 {
	my ($class, $text) = @_;

	my @s = split //, $text;

	my @b64 = split //, $B64_DH1080;
    my @d = ();

    my $L = scalar(@s) * 8;
    my $m = 0x80;
	my $i = 0;
	my $j = 0;
	my $k = 0;
	my $t = 0;

    while ($i < $L) {
		$t |= 1 if ord($s[$i >> 3]) & $m;
		$j += 1;
        $m >>= 1;
		if (!$m) {
			$m = 0x80;
		}
		if ($j % 6 == 0) {
            $d[$k] = $b64[$t];
            $t &= 0;
            $k += 1;
		}
        $t <<= 1;
        $t %= 0x100;
        #
        $i += 1;
	}
    $m = 5 - $j % 6;
    $t <<= $m;
    $t %= 0x100;
	if ($m) {
        $d[$k] = $b64[$t];
        $k += 1;
	}
    $d[$k] = '';
    my $res = '';
    foreach my $q (@d) {
		last if $q eq '';
        $res .= $q;
	}
    return $res
}

sub decodeB64 {
	my ($class, $text) = @_;

	my @s = split //, $text;

	my @b64 = split //, $B64_DH1080;
	my @buf = ();

	for my $i (0..63) {
		$buf[ord($b64[$i])] = $i;
	}

	my $L = scalar(@s);

	return undef if $L < 2;

	foreach my $i (reverse(0..$L-1)) {
		if ($buf[ord($s[$i])] == 0) {
			$L -= 1;
		}
		else {
			last;
		}
	}

	return undef if $L < 2;

	my @d = ();
    # d = [0]*L

	my $i = 0;
	my $k = 0;

	while (1) {
		$i += 1;

		if ($k + 1 < $L) {
			$d[$i-1] = $buf[ord($s[$k])] << 2;
			$d[$i-1] %= 0x100;
		}
		else {
			last;
		}
		$k += 1;
		if ($k < $L) {
			$d[$i - 1] |= $buf[ord($s[$k])] >> 4;
		}
		else {
			last;
		}

		$i += 1;
		if ($k + 1 < $L) {
			$d[$i - 1] = $buf[ord($s[$k])] << 4;
			$d[$i - 1] %= 0x100;
		}
		else {
			last;
		}

		$k += 1;
		if ($k < $L) {
			$d[$i - 1] |= $buf[ord($s[$k])] >> 2;
		}
		else {
			last;
		}

		$i += 1;
		if ($k + 1 < $L) {
			$d[$i-1] = $buf[ord($s[$k])] << 6;
			$d[$i-1] %= 0x100;
		}
		else {
			last;
		}
		$k += 1;
		if ($k < $L) {
			$d[$i - 1] |= $buf[ord($s[$k])] % 0x100;
		}
		else {
			last;
		}
		$k += 1;
	}
	return join ("", map(chr, splice(@d, 0, $i - 1)));
}

sub to_hex {
	my ($class, $binary) = @_;
	return '0x' . unpack("H*", $binary);
}

1;

__END__

=head1 NAME

Crypt::ircDH1080 - Perl extension irc DH1080 key exchange

=head1 SYNOPSIS

  use Crypt::ircDH1080;

=head1 DESCRIPTION

Blah blah blah.

=head1 AUTHOR

Tanesha

=head1 COPYRIGHT AND LICENSE

Copyright (C) 2009 by Tanesha

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself, either Perl version 5.10.0 or,
at your option, any later version of Perl 5 you may have available.

=cut
